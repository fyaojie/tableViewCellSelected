//
//  DataModel.h
//  TableViewCell的全选单选
//
//  Created by 冯垚杰 on 16/7/30.
//  Copyright © 2016年 冯垚杰. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface DataModel : NSObject

@property (nonatomic,copy) NSString *title;

@property (nonatomic, assign) BOOL isSelected;

@end
