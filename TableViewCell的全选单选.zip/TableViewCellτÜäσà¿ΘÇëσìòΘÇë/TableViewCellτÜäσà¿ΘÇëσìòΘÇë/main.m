//
//  main.m
//  TableViewCell的全选单选
//
//  Created by 冯垚杰 on 16/7/30.
//  Copyright © 2016年 冯垚杰. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
