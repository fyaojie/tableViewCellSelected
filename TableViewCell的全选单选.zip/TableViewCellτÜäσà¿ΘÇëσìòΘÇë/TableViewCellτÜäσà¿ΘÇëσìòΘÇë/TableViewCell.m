//
//  TableViewCell.m
//  TableViewCell的全选单选
//
//  Created by 冯垚杰 on 16/7/30.
//  Copyright © 2016年 冯垚杰. All rights reserved.
//

#import "TableViewCell.h"

@implementation TableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
- (IBAction)click:(UIButton *)sender {
    
    sender.selected = !sender.selected;
    
    self.changeSelected(sender.selected);
}

@end
