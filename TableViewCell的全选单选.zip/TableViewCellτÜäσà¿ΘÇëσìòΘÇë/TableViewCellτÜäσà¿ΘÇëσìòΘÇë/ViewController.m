//
//  ViewController.m
//  TableViewCell的全选单选
//
//  Created by 冯垚杰 on 16/7/30.
//  Copyright © 2016年 冯垚杰. All rights reserved.
//

#import "ViewController.h"
#import "TableViewCell.h"
#import "DataModel.h"

@interface ViewController () <UITableViewDataSource,UITableViewDelegate>

@property (weak, nonatomic) IBOutlet UITableView *tableView;

@property (nonatomic,strong) NSMutableArray *dataMuArray;

@property (nonatomic, assign) BOOL isSelected;

@property (nonatomic,strong) NSMutableArray *selectedArray;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.isSelected = NO;
}

- (NSMutableArray *)selectedArray {
    if (!_selectedArray) {
        _selectedArray = [NSMutableArray array];
    }
    return _selectedArray;
}

- (NSMutableArray *)dataMuArray
{
    if (!_dataMuArray) {
        _dataMuArray = [NSMutableArray array];
        
        NSArray * tempArray = @[@"在我心中 曾经有一个梦",
                                @"要用歌声让你忘了所有的痛",
                                @"灿烂星空 谁是真的英雄",
                                @"平凡的人们给我最多感动",
                                @"再没有恨 也没有了痛",
                                @"但愿人间处处都有爱的影踪",
                                @"用我们的歌 换你真心笑容",
                                @"祝福你的人生从此与众不同",
                              ];
        /**
         *    @"把握生命里的每一分钟",
         @"全力以赴我们心中的梦",
         @"不经历风雨 怎么见彩虹",
         @"没有人能随随便便成功",
         @"把握生命里每一次感动",
         @"和心爱的朋友热情相拥",
         @"让真心的话 和开心的泪",
         @"在你我的心里流动"

         */
        [tempArray enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
            DataModel *model = [[DataModel alloc] init];
            model.isSelected = NO;
            model.title = obj;
            [_dataMuArray addObject:model];
        }];
    }
    return _dataMuArray;
};


#pragma mark  UITableViewDataSource - UITableViewDelegate

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    return 50;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    button.frame = CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, 50);
    [button setTitle:@"点击全选" forState:UIControlStateNormal];
    [button setTitle:@"取消全选" forState:UIControlStateSelected];
    button.selected = self.isSelected;
    [button setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    button.backgroundColor = [UIColor grayColor];
    [button addTarget:self action:@selector(click:) forControlEvents:UIControlEventTouchUpInside];
    return button;
}

- (void)click:(UIButton *)button {
    self.isSelected = !self.isSelected;
    
    [self.dataMuArray enumerateObjectsUsingBlock:^(DataModel *model, NSUInteger idx, BOOL * _Nonnull stop) {
        model.isSelected = !button.selected;
    }];
    [self.selectedArray removeAllObjects];
    if (self.isSelected) {
        self.selectedArray = [NSMutableArray arrayWithArray:self.dataMuArray];
    }

    NSLog(@"%@",self.selectedArray);
    [self.tableView reloadData];
}

/* 行数 **/
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.dataMuArray.count;
}


/* cell设置 **/
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    TableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"TableViewCell"];
    
    DataModel *model = self.dataMuArray[indexPath.row];
    
    [cell setChangeSelected:^(BOOL currentSelected) {
        if (currentSelected) {
            model.isSelected = YES;
            [self.selectedArray addObject:model];
        }
        else {
            model.isSelected = NO;
            [self.selectedArray removeObject:model];
        }
        
        
        __block BOOL isAll = YES;
        [self.dataMuArray enumerateObjectsUsingBlock:^(DataModel *model, NSUInteger idx, BOOL * _Nonnull stop) {
            if (!model.isSelected) {
                isAll = NO;
                *stop = YES;
            }
        }];
        
        if (isAll) {
            self.isSelected = YES;
            [self.tableView reloadData];
        }
        
        NSLog(@"%@",self.selectedArray);
    }];
    
    cell.chooseButton.selected = model.isSelected;
    cell.titleLabel.text = model.title;
    
    return cell;
}


@end
